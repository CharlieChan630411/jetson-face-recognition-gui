# jetsoncv 模組初始化
__version__ = "0.1"
